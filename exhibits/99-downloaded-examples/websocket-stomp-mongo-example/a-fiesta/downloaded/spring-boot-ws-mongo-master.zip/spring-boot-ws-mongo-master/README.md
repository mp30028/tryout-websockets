Example using Spring Boot / STOMP WebSockets / MongoDB

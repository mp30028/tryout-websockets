package com.okanmenevseoglu.chatapp.model;

public enum MessageAction {

    JOIN,
    MESSAGE,
    LEAVE
}